const https = require('https');

const TELEGRAM_TOKEN = "8749221727:AAGFbuXHjCOhQpxBnXkxEzyO-6BOZj8DKFo";
const GEMINI_API_KEY = "AIzaSyC12dfNqzjsxrf6eOIf7VkKtxGl5gsbYD0";
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;

const SYSTEM_PROMPT = `You are a friendly expert Freelancing Guide Bot helping Bangladeshi youth start freelancing on Upwork, Fiverr, and Freelancer.com.

Reply in the SAME language the user writes:
- If they write in Bangla → reply in Bangla
- If they write in English → reply in English
- If they mix both → use both

You help with:
1. Getting started on Upwork/Fiverr
2. Building portfolio and profile (even with zero experience)
3. Finding first clients and writing proposals
4. Pricing, rates, and negotiation
5. Creating ATS-friendly CVs

Be encouraging, practical, and specific to Bangladesh context (mention bKash, dollar earnings, local freelancing community). Keep responses clear, concise, and helpful. Use emojis to be friendly.`;

// Store conversation history per user
const userHistory = {};

function httpsRequest(url, options, body) {
  return new Promise((resolve, reject) => {
    const req = https.request(url, options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { resolve(data); }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

async function sendTelegramMessage(chatId, text) {
  const body = JSON.stringify({ chat_id: chatId, text: text, parse_mode: 'Markdown' });
  const url = new URL(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`);
  await httpsRequest(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
  }, body);
}

async function askGemini(userId, userMessage) {
  if (!userHistory[userId]) userHistory[userId] = [];
  userHistory[userId].push({ role: 'user', parts: [{ text: userMessage }] });

  // Keep last 10 messages only
  if (userHistory[userId].length > 10) {
    userHistory[userId] = userHistory[userId].slice(-10);
  }

  const body = JSON.stringify({
    system_instruction: { parts: [{ text: SYSTEM_PROMPT }] },
    contents: userHistory[userId],
    generationConfig: { maxOutputTokens: 800, temperature: 0.7 }
  });

  const url = new URL(GEMINI_URL);
  const data = await httpsRequest(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
  }, body);

  const reply = data?.candidates?.[0]?.content?.parts?.[0]?.text || 'দুঃখিত, উত্তর পাওয়া যায়নি। Please try again.';
  userHistory[userId].push({ role: 'model', parts: [{ text: reply }] });
  return reply;
}

async function getUpdates(offset) {
  const url = new URL(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/getUpdates`);
  const body = JSON.stringify({ offset, timeout: 30, limit: 100 });
  return await httpsRequest(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
  }, body);
}

async function handleMessage(message) {
  const chatId = message.chat.id;
  const userId = message.from.id;
  const text = message.text;

  if (!text) return;

  console.log(`Message from ${userId}: ${text}`);

  if (text === '/start') {
    const welcome = `🇧🇩 *স্বাগতম! Welcome to Freelancing Guide Bot!*\n\nআমি আপনাকে ফ্রিল্যান্সিং শুরু করতে সাহায্য করবো!\n\nI can help you with:\n🚀 Getting started on Upwork/Fiverr\n📁 Building your profile & portfolio\n🤝 Finding your first client\n💰 Pricing & negotiation tips\n📄 Creating ATS-friendly CV\n\nবাংলায় বা English এ প্রশ্ন করুন! Ask me anything! 👇`;
    await sendTelegramMessage(chatId, welcome);
    return;
  }

  if (text === '/help') {
    const help = `*Available commands:*\n\n/start - Welcome message\n/help - Show this help\n/reset - Clear conversation history\n\n*Topics I can help with:*\n• Upwork/Fiverr শুরু করা\n• Profile & Portfolio তৈরি\n• First client পাওয়া\n• Pricing & negotiation\n• ATS-friendly CV তৈরি`;
    await sendTelegramMessage(chatId, help);
    return;
  }

  if (text === '/reset') {
    userHistory[userId] = [];
    await sendTelegramMessage(chatId, '✅ Conversation reset! নতুন করে শুরু করুন।');
    return;
  }

  // Show typing indicator
  const typingUrl = new URL(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendChatAction`);
  const typingBody = JSON.stringify({ chat_id: chatId, action: 'typing' });
  await httpsRequest(typingUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(typingBody) }
  }, typingBody);

  try {
    const reply = await askGemini(userId, text);
    // Clean markdown for Telegram
    const cleaned = reply.replace(/\*\*(.*?)\*\*/g, '*$1*');
    await sendTelegramMessage(chatId, cleaned);
  } catch (err) {
    console.error('Error:', err);
    await sendTelegramMessage(chatId, '⚠️ Sorry, something went wrong. Please try again!');
  }
}

async function startPolling() {
  console.log('🤖 Freelancing Guide Bot is running...');
  let offset = 0;

  while (true) {
    try {
      const data = await getUpdates(offset);
      if (data.result && data.result.length > 0) {
        for (const update of data.result) {
          offset = update.update_id + 1;
          if (update.message) {
            await handleMessage(update.message);
          }
        }
      }
    } catch (err) {
      console.error('Polling error:', err.message);
      await new Promise(r => setTimeout(r, 3000));
    }
  }
}

startPolling();
